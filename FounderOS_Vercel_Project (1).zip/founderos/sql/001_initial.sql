-- Run in Supabase SQL editor as project owner. All user-facing access is covered by RLS.
create extension if not exists pgcrypto;
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 full_name text not null default '', timezone text not null default 'Asia/Kolkata',
 review_hour integer not null default 21 check(review_hour between 0 and 23),
 email_reminders boolean not null default false, push_reminders boolean not null default false,
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create table if not exists public.tasks (
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 title text not null check(length(title) between 1 and 240), description text not null default '',
 due_at timestamptz,person text,location text,priority text not null default 'medium' check(priority in ('low','medium','high')),
 category text not null default 'General',status text not null default 'pending' check(status in ('pending','in_progress','completed','postponed','cancelled')),
 completed_at timestamptz,reminder_minutes integer check(reminder_minutes between 0 and 10080) default 30,
 reminder_version uuid not null default gen_random_uuid(),
 created_at timestamptz not null default now(),updated_at timestamptz not null default now()
);
create index if not exists tasks_user_due_idx on public.tasks (user_id,due_at);
create index if not exists tasks_user_status_idx on public.tasks(user_id,status);
create table if not exists public.task_events (
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 task_id uuid not null references public.tasks(id) on delete cascade,
 event_type text not null, previous_status text,new_status text,notes text,
 created_at timestamptz not null default now()
);
create index if not exists events_user_created on public.task_events(user_id,created_at);
create table if not exists public.push_subscriptions(
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 endpoint text not null, keys jsonb not null,created_at timestamptz not null default now(),
 unique (user_id,endpoint)
);
create table if not exists public.notification_log (
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 task_id uuid references public.tasks(id) on delete set null,reminder_version uuid,
 channel text not null,status text not null default 'queued',error text,
 created_at timestamptz not null default now(),unique(task_id,reminder_version,channel)
);
create table if not exists public.daily_reviews (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
 report_text text not null, created_at timestamptz not null default now()
);
create table if not exists public.weekly_reports (
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 week_start date not null,metrics jsonb not null default '{}'::jsonb,
 file_path text not null,created_at timestamptz not null default now(),
 unique(user_id,week_start)
);
create table if not exists public.ai_requests (
 id uuid primary key default gen_random_uuid(),user_id uuid not null references auth.users(id) on delete cascade,
 request_key text not null,kind text not null,created_at timestamptz not null default now(),
 unique(user_id,kind,request_key)
);
create or replace function public.update_task_stamp() returns trigger language plpgsql as $$
begin
 new.updated_at=now();
 if new.status is distinct from old.status or new.due_at is distinct from old.due_at or new.reminder_minutes is distinct from old.reminder_minutes then
  new.reminder_version=gen_random_uuid();
 end if;
 if new.status='completed' and old.status is distinct from 'completed' then new.completed_at=now();
 elsif new.status<>'completed' and old.status='completed' then new.completed_at=null;
 end if;
 return new;
end $$;
drop trigger if exists tasks_update_stamp on public.tasks;
create trigger tasks_update_stamp before update on public.tasks for each row execute function public.update_task_stamp();
create or replace function public.new_user_profile() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id,full_name) values(new.id,coalesce(new.raw_user_meta_data->>'full_name','')) on conflict do nothing;return new;end $$;
drop trigger if exists new_user_profile_trigger on auth.users;
create trigger new_user_profile_trigger after insert on auth.users for each row execute function public.new_user_profile();
insert into public.profiles(id) select id from auth.users on conflict do nothing;
-- Prevent event falsification by clients: events and logs inserted only by verified server using service role.
-- task and profile CRUD is authenticated with row-scoped policies.
alter table public.profiles enable row level security;
alter table public.tasks enable row level security;
alter table public.task_events enable row level security;
alter table public.push_subscriptions enable row level security;
alter table public.notification_log enable row level security;
alter table public.daily_reviews enable row level security;
alter table public.weekly_reports enable row level security;
alter table public.ai_requests enable row level security;
create policy "profile read" on public.profiles for select to authenticated using(id=auth.uid());
create policy "profile update" on public.profiles for update to authenticated using(id=auth.uid()) with check(id=auth.uid());
create policy "tasks select" on public.tasks for select to authenticated using(user_id=auth.uid());
create policy "tasks insert" on public.tasks for insert to authenticated with check(user_id=auth.uid());
create policy "tasks update" on public.tasks for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "tasks delete" on public.tasks for delete to authenticated using(user_id=auth.uid());
create policy "events select" on public.task_events for select to authenticated using(user_id=auth.uid());
create policy "push read" on public.push_subscriptions for select to authenticated using(user_id=auth.uid());
create policy "push insert" on public.push_subscriptions for insert to authenticated with check(user_id=auth.uid());
create policy "push delete" on public.push_subscriptions for delete to authenticated using(user_id=auth.uid());
create policy "notification read" on public.notification_log for select to authenticated using(user_id=auth.uid());
create policy "reviews select" on public.daily_reviews for select to authenticated using(user_id=auth.uid());
create policy "reviews insert" on public.daily_reviews for insert to authenticated with check(user_id=auth.uid());
create policy "reports read" on public.weekly_reports for select to authenticated using(user_id=auth.uid());
create policy "ai insert" on public.ai_requests for insert to authenticated with check(user_id=auth.uid());
-- Private bucket for PDF bytes; access/download performed via signed URLs after user authorization.
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types) values('founderos-reports','founderos-reports',false,10485760,array['application/pdf']) on conflict(id) do nothing;
-- Append-only task audit, written by trigger as table owner rather than by untrusted clients.
create or replace function public.audit_task_change() returns trigger language plpgsql security definer set search_path=public as $$
begin
 if tg_op='INSERT' then
  insert into public.task_events(user_id,task_id,event_type,new_status) values(new.user_id,new.id,'created',new.status);
  return new;
 end if;
 if new.status is distinct from old.status then
  insert into public.task_events(user_id,task_id,event_type,previous_status,new_status)
  values(new.user_id,new.id,'status_changed',old.status,new.status);
 end if;
 if new.due_at is distinct from old.due_at then
  insert into public.task_events(user_id,task_id,event_type,notes)
  values(new.user_id,new.id,'rescheduled',coalesce(old.due_at::text,'unscheduled')||' -> '||coalesce(new.due_at::text,'unscheduled'));
 end if;
 return new;
end $$;
drop trigger if exists tasks_audit on public.tasks;
create trigger tasks_audit after insert or update on public.tasks for each row execute function public.audit_task_change();
-- Atomic, idempotent batch task creation via SQL RPC.
create table if not exists public.task_batches (
 user_id uuid not null references auth.users(id) on delete cascade,
 request_key uuid not null,
 task_ids uuid[] not null default '{}',
 created_at timestamptz not null default now(),
 primary key(user_id,request_key)
);
alter table public.task_batches enable row level security;
create policy "batches read" on public.task_batches for select to authenticated using(user_id=auth.uid());
create policy "batches insert" on public.task_batches for insert to authenticated with check(user_id=auth.uid());
create policy "batches update" on public.task_batches for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create or replace function public.create_tasks_batch(p_key uuid,p_tasks jsonb)
returns setof public.tasks language plpgsql security invoker set search_path=public as $$
declare uid uuid := auth.uid();created_ids uuid[];
begin
 if uid is null then raise exception 'Authentication required';end if;
 if jsonb_typeof(p_tasks)<>'array' or jsonb_array_length(p_tasks)<1 or jsonb_array_length(p_tasks)>25 then raise exception 'Invalid task batch';end if;
 insert into public.task_batches(user_id,request_key) values(uid,p_key) on conflict do nothing;
 if found then
  with inserted as (
    insert into public.tasks(user_id,title,description,due_at,person,location,priority,category,status)
    select uid,x.title,coalesce(x.description,''),x.due_at,x.person,x.location,coalesce(x.priority,'medium'),coalesce(x.category,'General'),coalesce(x.status,'pending')
    from jsonb_to_recordset(p_tasks) as x(title text,description text,due_at timestamptz,person text,location text,priority text,category text,status text)
    returning id
  ) select coalesce(array_agg(id),'{}'::uuid[]) into created_ids from inserted;
  update public.task_batches set task_ids=created_ids where user_id=uid and request_key=p_key;
 else
  select task_ids into created_ids from public.task_batches where user_id=uid and request_key=p_key;
 end if;
 return query select t.* from public.tasks t where t.user_id=uid and t.id=any(created_ids);
end $$;
revoke all on function public.create_tasks_batch(uuid,jsonb) from public;
grant execute on function public.create_tasks_batch(uuid,jsonb) to authenticated;
create table if not exists public.review_reminder_jobs(
 id uuid primary key default gen_random_uuid(),
 user_id uuid not null references auth.users(id) on delete cascade,
 local_date date not null,hour integer not null check(hour between 0 and 23),
 scheduled_at timestamptz not null,
 message_id text,status text not null default 'pending',
 created_at timestamptz not null default now(),
 unique(user_id,local_date,hour)
);
alter table public.review_reminder_jobs enable row level security;
create policy "review jobs read" on public.review_reminder_jobs for select to authenticated using(user_id=auth.uid());
create policy "review jobs insert" on public.review_reminder_jobs for insert to authenticated with check(user_id=auth.uid());
create policy "review jobs update" on public.review_reminder_jobs for update to authenticated using(user_id=auth.uid()) with check(user_id=auth.uid());
create policy "review jobs delete" on public.review_reminder_jobs for delete to authenticated using(user_id=auth.uid());
