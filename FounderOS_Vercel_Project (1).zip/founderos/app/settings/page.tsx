import {supabaseServer} from '@/lib/supabase';import {redirect} from 'next/navigation';import Settings from '@/components/settings';
export default async function SettingsPage(){const s=await supabaseServer();const {data:{user}}=await s.auth.getUser();if(!user)redirect('/login');return <Settings email={user.email||''}/>}
