import {supabaseServer} from '@/lib/supabase';import {redirect} from 'next/navigation';import Dashboard from '@/components/dashboard';
export default async function Tasks(){const s=await supabaseServer();const {data:{user}}=await s.auth.getUser();if(!user)redirect('/login');return <Dashboard email={user.email||''} all/>}
