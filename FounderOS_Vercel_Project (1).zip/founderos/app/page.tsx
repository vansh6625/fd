import {redirect} from 'next/navigation';import {supabaseServer} from '@/lib/supabase';import Dashboard from '@/components/dashboard';
export default async function Home(){if(!process.env.NEXT_PUBLIC_SUPABASE_URL||!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)return <main className="center">Configure Supabase environment variables to start FounderOS. See README.md.</main>;
 const supabase=await supabaseServer();const {data:{user}}=await supabase.auth.getUser();if(!user)redirect('/login');return <Dashboard email={user.email||''}/>}
