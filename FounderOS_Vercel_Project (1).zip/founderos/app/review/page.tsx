import {supabaseServer} from '@/lib/supabase';import {redirect} from 'next/navigation';import Review from '@/components/review';
export default async function ReviewPage(){const s=await supabaseServer();const {data:{user}}=await s.auth.getUser();if(!user)redirect('/login');return <Review email={user.email||''}/>}
