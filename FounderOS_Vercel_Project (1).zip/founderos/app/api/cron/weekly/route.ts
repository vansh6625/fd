import {supabaseAdmin} from '@/lib/supabase';import {makeReport} from '@/lib/reports';import {lastClosedWeek} from '@/lib/week.mjs';import type {Task} from '@/lib/schema';import {ok} from '@/lib/http';
export const runtime='nodejs';export const maxDuration=60;
export async function GET(req:Request){
 const auth=req.headers.get('authorization');if(!process.env.CRON_SECRET||auth!==`Bearer ${process.env.CRON_SECRET}`)return ok({error:'Unauthorized'},401);
 const admin=supabaseAdmin();const {start,end,weekStart:week}=lastClosedWeek();
 let success=0,failed=0;let offset=0;
 while(true){const {data:profiles,error}=await admin.from('profiles').select('id,full_name').range(offset,offset+49);if(error)return ok({error:'Unable to list users'},500);if(!profiles?.length)break;
 for(const p of profiles){try{
 const {data:existing}=await admin.from('weekly_reports').select('id').eq('user_id',p.id).eq('week_start',week).maybeSingle();if(existing)continue;
 const {data:tasks,error:loadError}=await admin.from('tasks').select('*').eq('user_id',p.id).limit(2000);if(loadError)throw loadError;
 const {buffer,metrics}=await makeReport(tasks as Task[]||[],p.full_name,start,end);const file_path=`${p.id}/${week}.pdf`;
 const {error:uploadError}=await admin.storage.from('founderos-reports').upload(file_path,buffer,{contentType:'application/pdf',upsert:false});if(uploadError&&!uploadError.message.includes('already exists'))throw uploadError;
 const {error:saveError}=await admin.from('weekly_reports').upsert({user_id:p.id,week_start:week,file_path,metrics},{onConflict:'user_id,week_start'});if(saveError)throw saveError;success++;
 }catch(e){failed++;console.error('Weekly report failed',p.id,e)}}
 if(profiles.length<50)break;offset+=50;
 }
 return ok({generated:success,failed});
}
