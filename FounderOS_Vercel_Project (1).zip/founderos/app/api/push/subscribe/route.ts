import {requireUser} from '@/lib/supabase';import {ok,failure,originOK,bodyJSON} from '@/lib/http';import {z} from 'zod';
export async function POST(req:Request){try{
 if(!originOK(req))return ok({error:'Invalid origin'},403);
 const {supabase,user}=await requireUser();const body=z.object({endpoint:z.string().url().startsWith('https://'),keys:z.object({p256dh:z.string().min(10),auth:z.string().min(5)})}).parse(await bodyJSON(req,5000));
 const {error}=await supabase.from('push_subscriptions').upsert({user_id:user.id,endpoint:body.endpoint,keys:body.keys},{onConflict:'user_id,endpoint'});if(error)throw error;return ok({subscribed:true});
}catch(e){return failure(e)}}
