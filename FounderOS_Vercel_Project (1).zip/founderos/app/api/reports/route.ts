import {requireUser,supabaseAdmin} from '@/lib/supabase';import {ok,failure,originOK} from '@/lib/http';import {makeReport} from '@/lib/reports';import {lastClosedWeek} from '@/lib/week.mjs';import type {Task} from '@/lib/schema';
export const runtime='nodejs';export const maxDuration=60;
export async function GET(){try{const {supabase,user}=await requireUser();const {data,error}=await supabase.from('weekly_reports').select('id,week_start,metrics,created_at').eq('user_id',user.id).order('week_start',{ascending:false}).limit(60);if(error)throw error;return ok({reports:data})}catch(e){return failure(e)}}
export async function POST(req:Request){try{
 if(!originOK(req))return ok({error:'Invalid origin'},403);
 const {supabase,user}=await requireUser();const {start,end,weekStart:week}=lastClosedWeek();const {data:prior}=await supabase.from('weekly_reports').select('id').eq('week_start',week).eq('user_id',user.id).maybeSingle();if(prior)return ok({id:prior.id,alreadyGenerated:true});
 const {data,error}=await supabase.from('tasks').select('*').eq('user_id',user.id).limit(2000);if(error)throw error;
 const {data:profile}=await supabase.from('profiles').select('full_name').eq('id',user.id).single();
 const result=await makeReport(data as Task[]||[],profile?.full_name||user.email||'Founder',start,end);
 const path=`${user.id}/${week}.pdf`;
 const {error:upload}=await supabaseAdmin().storage.from('founderos-reports').upload(path,result.buffer,{contentType:'application/pdf',upsert:false});if(upload && !upload.message.includes('already exists'))throw upload;
 const {data:report,error:dbError}=await supabaseAdmin().from('weekly_reports').upsert({user_id:user.id,week_start:week,metrics:result.metrics,file_path:path},{onConflict:'user_id,week_start'}).select('id').single();if(dbError)throw dbError;
 return ok({id:report.id,metrics:result.metrics});
}catch(e){return failure(e)}}
