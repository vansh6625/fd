import {requireUser,supabaseAdmin} from '@/lib/supabase';import {ok,failure} from '@/lib/http';
export async function GET(req:Request){try{const {supabase,user}=await requireUser();const id=new URL(req.url).searchParams.get('id');if(!id||!/^[0-9a-f-]{36}$/i.test(id))return ok({error:'Invalid report'},400);
const {data}=await supabase.from('weekly_reports').select('file_path').eq('id',id).eq('user_id',user.id).single();if(!data)return ok({error:'Report not found'},404);
const {data:signed,error}=await supabaseAdmin().storage.from('founderos-reports').createSignedUrl(data.file_path,60);if(error||!signed)return ok({error:'Download unavailable'},500);return Response.redirect(signed.signedUrl,302);
}catch(e){return failure(e)}}
