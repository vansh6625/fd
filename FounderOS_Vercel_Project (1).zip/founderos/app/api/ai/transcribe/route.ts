import {requireUser} from '@/lib/supabase';import {ok,failure,originOK} from '@/lib/http';
export const runtime='nodejs';
export async function POST(req:Request){try{
 if(!originOK(req))return ok({error:'Invalid origin'},403);
 await requireUser();if(!process.env.OPENAI_API_KEY)return ok({error:'Speech service not configured'},503);
 const form=await req.formData();const audio=form.get('audio');
 if(!(audio instanceof File)||audio.size<100||audio.size>10*1024*1024)return ok({error:'Provide an audio file below 10 MB'},400);
 if(!['audio/webm','audio/ogg','audio/mp4','audio/mpeg','audio/wav','audio/x-wav','audio/mp3','audio/mp4;codecs=mp4a.40.2','audio/webm;codecs=opus'].includes(audio.type))return ok({error:'Unsupported audio format'},415);
 const upstream=new FormData();upstream.append('file',audio,'voice.'+(audio.type.includes('ogg')?'ogg':audio.type.includes('mp4')?'mp4':audio.type.includes('wav')?'wav':'webm'));upstream.append('model','gpt-4o-mini-transcribe');
 const ctrl=new AbortController();const timeout=setTimeout(()=>ctrl.abort(),60000);
 try{const r=await fetch('https://api.openai.com/v1/audio/transcriptions',{method:'POST',headers:{Authorization:`Bearer ${process.env.OPENAI_API_KEY}`},body:upstream,signal:ctrl.signal});if(!r.ok)return ok({error:`Transcription provider returned ${r.status}`},502);const data=await r.json();return ok({text:data.text});}
 finally{clearTimeout(timeout)}
}catch(e){return failure(e)}}
