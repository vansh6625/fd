import {requireUser} from '@/lib/supabase';import {ok,failure,originOK,bodyJSON} from '@/lib/http';import {extractTasks} from '@/lib/ai';import {z} from 'zod';
export const runtime='nodejs';
export async function POST(req:Request){try{
 if(!originOK(req))return ok({error:'Invalid origin'},403);
 const {user,supabase}=await requireUser();const {text,timezone}=z.object({text:z.string().trim().min(1).max(4500),timezone:z.string().min(3).max(60).default('Asia/Kolkata')}).parse(await bodyJSON(req,10000));
 const cutoff=new Date(Date.now()-3600000).toISOString();const {count}=await supabase.from('ai_requests').select('id',{count:'exact',head:true}).eq('user_id',user.id).eq('kind','extraction').gte('created_at',cutoff);
 if((count||0)>=40)return ok({error:'Hourly AI usage limit reached'},429);
 await supabase.from('ai_requests').insert({user_id:user.id,kind:'extraction',request_key:crypto.randomUUID()});
 return ok(await extractTasks(text,timezone));
}catch(e){return failure(e)}}
