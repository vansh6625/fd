import {requireUser} from '@/lib/supabase';
import {ok,failure,bodyJSON,originOK} from '@/lib/http';
import {taskSchema,taskUpdateSchema} from '@/lib/schema';
import {scheduleReminder} from '@/lib/reminders';
import {z} from 'zod';
export const runtime='nodejs';
export async function GET(){try{const {supabase,user}=await requireUser();const {data,error}=await supabase.from('tasks').select('*').eq('user_id',user.id).order('created_at',{ascending:false}).limit(500);if(error)throw error;return ok({tasks:data});}catch(e){return failure(e)}}
export async function POST(req:Request){try{
 if(!originOK(req))return ok({error:'Invalid origin'},403);
 const {supabase,user}=await requireUser();const body=z.object({tasks:z.array(taskSchema).min(1).max(25),request_key:z.string().uuid()}).parse(await bodyJSON(req));
 const {data,error}=await supabase.rpc('create_tasks_batch',{p_key:body.request_key,p_tasks:body.tasks});if(error)throw error;
 const issues=[];
 for(const task of data||[]){try{await scheduleReminder(task,user.id,task.reminder_minutes??30)}catch(e){issues.push(task.id);console.error('Reminder scheduling failed',task.id,e)}}
 return ok({tasks:data,schedulingWarnings:issues},201);
}catch(e){return failure(e)}}
export async function PATCH(req:Request){try{
 if(!originOK(req))return ok({error:'Invalid origin'},403);
 const {supabase,user}=await requireUser();const input=taskUpdateSchema.parse(await bodyJSON(req));const {id,...fields}=input;
 const {data:before,error:readErr}=await supabase.from('tasks').select('*').eq('id',id).eq('user_id',user.id).single();if(readErr||!before)return ok({error:'Task not found'},404);
 const {data,error}=await supabase.from('tasks').update(fields).eq('id',id).eq('user_id',user.id).select('*').single();if(error)throw error;
 const issues=[];
 if(data.due_at && data.status!=='completed' && data.status!=='cancelled') {try{await scheduleReminder(data,user.id,data.reminder_minutes??30)}catch(e){issues.push('Could not schedule reminder'); console.error(e)}}
 return ok({task:data,warnings:issues});
}catch(e){return failure(e)}}
export async function DELETE(req:Request){try{
 if(!originOK(req))return ok({error:'Invalid origin'},403);
 const {supabase,user}=await requireUser();const {id}=z.object({id:z.string().uuid()}).parse(await bodyJSON(req));
 const {error}=await supabase.from('tasks').delete().eq('id',id).eq('user_id',user.id);if(error)throw error;return ok({deleted:true});
}catch(e){return failure(e)}}
