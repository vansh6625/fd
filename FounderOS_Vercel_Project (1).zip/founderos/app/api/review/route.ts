import {requireUser} from '@/lib/supabase';import {ok,failure,bodyJSON,originOK} from '@/lib/http';import {z} from 'zod';
export const runtime='nodejs';
export async function POST(req:Request){try{
 if(!originOK(req))return ok({error:'Invalid origin'},403);
 const {supabase,user}=await requireUser();const parsed=z.object({report_text:z.string().min(1).max(4500),changes:z.array(z.object({id:z.string().uuid(),status:z.enum(['pending','in_progress','completed','postponed','cancelled'])})).max(100)}).parse(await bodyJSON(req));
 const ids=[...new Set(parsed.changes.map(t=>t.id))];
 if(ids.length){const {data,error}=await supabase.from('tasks').select('id').in('id',ids).eq('user_id',user.id);if(error)throw error;if(data?.length!==ids.length)return ok({error:'One or more tasks were not found'},404);}
 for(const change of parsed.changes){const {error}=await supabase.from('tasks').update({status:change.status}).eq('id',change.id).eq('user_id',user.id);if(error)throw error;}
 const {error}=await supabase.from('daily_reviews').insert({user_id:user.id,report_text:parsed.report_text});if(error)throw error;
 return ok({saved:true});
}catch(e){return failure(e)}}
