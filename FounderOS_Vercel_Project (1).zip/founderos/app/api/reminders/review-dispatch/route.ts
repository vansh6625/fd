import {Receiver} from '@upstash/qstash';import {supabaseAdmin} from '@/lib/supabase';import {ensureDailyReview} from '@/lib/daily-reminder';import {notifyUser} from '@/lib/notify';import {ok} from '@/lib/http';
export const runtime='nodejs';
export async function POST(req:Request){
 if(!process.env.QSTASH_CURRENT_SIGNING_KEY||!process.env.QSTASH_NEXT_SIGNING_KEY)return ok({error:'Not configured'},503);
 const body=await req.text();const signature=req.headers.get('upstash-signature')||'';
 const receiver=new Receiver({currentSigningKey:process.env.QSTASH_CURRENT_SIGNING_KEY,nextSigningKey:process.env.QSTASH_NEXT_SIGNING_KEY});
 const verified=await receiver.verify({signature,body,url:`${process.env.NEXT_PUBLIC_SITE_URL}/api/reminders/review-dispatch`}).catch(()=>false);
 if(!verified)return ok({error:'Unauthorized'},401);
 let input:{jobId:string,userId:string,date:string,hour:number};try{input=JSON.parse(body)}catch{return ok({error:'Invalid payload'},400)}
 const admin=supabaseAdmin();const {data:job}=await admin.from('review_reminder_jobs').select('*').eq('id',input.jobId).eq('user_id',input.userId).maybeSingle();if(!job)return ok({ignored:'Unknown job'});
 if(job.status==='sent')return ok({ignored:'Already sent'});
 const {data:profile}=await admin.from('profiles').select('review_hour').eq('id',input.userId).maybeSingle();
 if(profile?.review_hour===job.hour){const r=await notifyUser(input.userId,'Time for your daily review','Take two minutes to mark today’s work complete and carry forward any unfinished tasks.','/review');
 await admin.from('review_reminder_jobs').update({status:r.delivered?'sent':'not_delivered'}).eq('id',job.id);
 }else{await admin.from('review_reminder_jobs').update({status:'obsolete'}).eq('id',job.id)}
 if(profile){try{await ensureDailyReview(admin,input.userId,profile.review_hour)}catch(e){console.error('Could not schedule next review reminder',e);return ok({error:'Scheduling next daily reminder failed'},503)}}
 return ok({processed:true});
}
