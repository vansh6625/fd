import {Receiver} from '@upstash/qstash';import {supabaseAdmin} from '@/lib/supabase';import {ok} from '@/lib/http';import {notifyUser} from '@/lib/notify';
export const runtime='nodejs';
export async function POST(req:Request){
 if(!process.env.QSTASH_CURRENT_SIGNING_KEY||!process.env.QSTASH_NEXT_SIGNING_KEY)return ok({error:'Reminder service not configured'},503);
 const body=await req.text();const signature=req.headers.get('upstash-signature')||'';
 const receiver=new Receiver({currentSigningKey:process.env.QSTASH_CURRENT_SIGNING_KEY,nextSigningKey:process.env.QSTASH_NEXT_SIGNING_KEY});
 const valid=await receiver.verify({signature,body,url:`${process.env.NEXT_PUBLIC_SITE_URL}/api/reminders/dispatch`}).catch(()=>false);
 if(!valid)return ok({error:'Unauthorized'},401);
 let payload:{taskId:string,userId:string,version:string};try{payload=JSON.parse(body)}catch{return ok({error:'Invalid payload'},400)}
 if(!payload.taskId||!payload.userId||!payload.version)return ok({error:'Invalid payload'},400);
 const admin=supabaseAdmin();const {data:task,error}=await admin.from('tasks').select('*').eq('id',payload.taskId).eq('user_id',payload.userId).maybeSingle();if(error||!task)return ok({ignored:'Task not found'});
 if(task.updated_at!==payload.version||!task.due_at||['completed','cancelled'].includes(task.status))return ok({ignored:'Stale or inactive'});
 const {data:prior}=await admin.from('notification_log').select('status').eq('task_id',task.id).eq('reminder_version',task.reminder_version).eq('channel','attempt').maybeSingle();
 if(prior?.status==='sent')return ok({ignored:'Already delivered'});
 const sent=await notifyUser(payload.userId,'FounderOS: Upcoming task',`${task.title}\nDue: ${task.due_at}`,'/');
 await admin.from('notification_log').upsert({user_id:payload.userId,task_id:task.id,reminder_version:task.reminder_version,channel:'attempt',status:sent.delivered?'sent':'failed',error:sent.failures.join(',').slice(0,200)},{onConflict:'task_id,reminder_version,channel'});
 if(!sent.delivered&&sent.failures.length)return ok({error:'Notification provider failure'},503);
 return ok({processed:true,acceptedChannels:sent.delivered});
}
