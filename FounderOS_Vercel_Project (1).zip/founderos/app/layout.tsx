import './globals.css';import type {Metadata} from 'next';
export const metadata:Metadata={title:'FounderOS — Your work, organized',description:'AI-powered personal work assistant for founders',icons:{icon:'/icon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
