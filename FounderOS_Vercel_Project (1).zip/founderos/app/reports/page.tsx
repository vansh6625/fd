import {supabaseServer} from '@/lib/supabase';import {redirect} from 'next/navigation';import Reports from '@/components/reports';
export default async function ReportsPage(){const s=await supabaseServer();const {data:{user}}=await s.auth.getUser();if(!user)redirect('/login');return <Reports email={user.email||''}/>}
