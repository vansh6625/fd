# FounderOS

An early-stage Next.js application for capturing founder work in plain English, Hindi or Hinglish, converting text or voice into tasks, tracking daily progress, scheduling reminders, and generating weekly PDF reports.

## Implemented

- Supabase email authentication, cookie-based SSR sessions, profile and RLS-based user-scoped data.
- Dashboard with responsive task list, counters, completion, deletion, editing, status and priority display.
- Real OpenAI speech transcription API adapter and structured task extraction with editable pre-save review.
- Evening review via text, voice transcription and AI-proposed status matching (requires user approval).
- QStash-compatible durable, signed callback reminder flow; browser Web Push and optional Resend email.
- Weekly reports: last completed week, PDF rendering, private Supabase storage, downloadable signed links, weekly Vercel cron.
- Deployment scaffolding, schema migrations, validation, logging and local date/report logic tests.

## Requirements

- Node.js 20.11+ and npm
- Supabase project (Postgres + email auth + private object storage)
- OpenAI API key to activate multilingual transcription and structured extraction
- Upstash QStash for time-based reminders
- VAPID keys for browser push and/or Resend for email
- Vercel project and environment variables for deployment

## Setup

1. `npm install`
2. Copy `.env.example` to `.env.local` and fill valid values. Never commit secret keys.
3. In Supabase SQL editor, run `sql/001_initial.sql` against a new development project.
4. In Supabase Auth settings set site URL to `http://localhost:3000`, include `/auth/callback` in allowed redirect URLs; enable email+password sign-in and configure appropriate signup policy.
5. `npm run dev` and visit `http://localhost:3000`.
6. Sign up and confirm email, or use an account provisioned by your Supabase administrator.
7. Test task creation, AI extraction, and reminders with real API keys before production.

## Local checks

`npm test` — standalone calculation tests that do not require dependency installation.
`npm run typecheck` — strict TypeScript check (requires dependencies).
`npm run lint` — static lint check (requires dependencies).
`npm run build` — Next.js production build (requires dependencies).

## Production limitations and known gaps

**Do not treat this ZIP as deployed or production-verified.** The current creation environment cannot reach the npm registry and has no Vercel account deployment actions accessible in the tool session; full install/build and real provider tests have not run.

- **Unicode/Devanagari in PDFs:** The current PDF renderer uses Helvetica and substitutes unsupported non-Latin glyphs with `?`. This does **not** meet full Hindi PDF rendering requirements. Integrate an appropriately licensed Unicode/Indic font that the renderer supports, and confirm shaping/rendering with Hindi fixtures before claiming Hindi PDF support.
- **Daily review timed reminder:** A QStash-based daily review scheduling and signed callback flow is implemented, but live delivery has not been tested. It requires enabled push/email preferences, valid credentials, and verification of a real scheduled notification.
- **Idempotent task batches:** Atomic idempotent batch insertion is implemented via PostgreSQL RPC; it needs a real database integration test, including network retries.
- **Historical weekly reports:** Stored PDFs preserve data at generation time, but late completion/reopening changes and event-based historical computation require more rigorous reconciliation. Reports show current task status at generation time.
- **Reminders:** Requires real provider credentials, enabled notification preferences, a valid public callback URL, browser permissions and a successfully tested scheduled delivery. Scheduling errors are not a substitute for confirmed notifications.
- **Cron batch size:** The weekly report process pages through users in a single invocation and may exceed serverless duration for larger user counts. For scale, enqueue separate per-user jobs.
- **End-to-end, integration, load, vulnerability and deploy smoke tests:** Not run here; required before a production launch.
- **Signup policy:** By default, Supabase may allow public registrations; turn off public registration in Supabase for a private internal founder workspace.

See `DEPLOYMENT.md`, `ARCHITECTURE.md`, `SECURITY_REPORT.md`, `TEST_REPORT.md`, `FINAL_READINESS_REPORT.md`.
