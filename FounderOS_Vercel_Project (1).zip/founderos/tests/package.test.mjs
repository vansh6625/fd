import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
const root=path.resolve(import.meta.dirname,'..');
const read=x=>fs.readFileSync(path.join(root,x),'utf8');
test('critical endpoints exist',()=>{for(const file of ['app/api/tasks/route.ts','app/api/ai/transcribe/route.ts','app/api/ai/extract/route.ts','app/api/review/route.ts','app/api/reminders/dispatch/route.ts','app/api/cron/weekly/route.ts','app/api/reports/route.ts','app/api/reports/download/route.ts'])assert.ok(fs.existsSync(path.join(root,file)),file)});
test('the schema enables RLS on task, profile and report records',()=>{const sql=read('sql/001_initial.sql');for(const table of ['tasks','profiles','weekly_reports'])assert.match(sql,new RegExp(`alter table public\\.${table} enable row level security`))});
test('atomic server-side idempotency is represented in SQL and endpoint',()=>{assert.match(read('sql/001_initial.sql'),/create_tasks_batch/);assert.match(read('app/api/tasks/route.ts'),/supabase\.rpc\('create_tasks_batch'/)});
test('Vercel cron and private PDF storage are configured',()=>{assert.ok(JSON.parse(read('vercel.json')).crons.length);assert.match(read('sql/001_initial.sql'),/founderos-reports.*false/)});
