import test from 'node:test';import assert from 'node:assert/strict';import {lastClosedWeek,summarize,nextISTDaily} from '../lib/week.mjs';
test('previous Monday starts at IST midnight even on Sunday',()=>{
 const {start,end,weekStart}=lastClosedWeek(new Date('2026-10-25T19:00:00Z'));
 assert.equal(weekStart,'2026-10-19');assert.equal(start.toISOString(),'2026-10-18T18:30:00.000Z');assert.equal(end.toISOString(),'2026-10-25T18:30:00.000Z');
});
test('Monday after 00:00 IST moves to preceding week',()=>{
 const {weekStart}=lastClosedWeek(new Date('2026-10-26T00:00:00Z'));assert.equal(weekStart,'2026-10-19');
});
test('week includes its first instant and excludes next Monday',()=>{
 const {start,end}=lastClosedWeek(new Date('2026-10-26T00:00:00Z'));
 const s=summarize([{created_at:start.toISOString(),status:'completed',due_at:null,completed_at:start.toISOString()},{created_at:end.toISOString(),status:'pending',due_at:null,completed_at:null}],start,end);
 assert.equal(s.planned,1);assert.equal(s.completed,1);assert.equal(s.completionRate,100);
});
test('cancelled tasks are separate from pending',()=>{
 const start=new Date('2026-10-18T18:30:00Z'),end=new Date('2026-10-25T18:30:00Z');
 const s=summarize(['completed','cancelled','pending','postponed'].map(status=>({created_at:'2026-10-20T12:00:00Z',status,due_at:null,completed_at:null})),start,end);
 assert.deepEqual([s.planned,s.completed,s.cancelled,s.pending,s.completionRate],[4,1,1,2,25]);
});
test('zero-task report never divides by zero',()=>assert.equal(summarize([],new Date(0),new Date()).completionRate,0));

test('next review correctly uses IST and rolls to next day',()=>{
 const upcoming=nextISTDaily(21,new Date('2026-10-25T14:00:00Z'));
 assert.equal(upcoming.when.toISOString(),'2026-10-25T15:30:00.000Z');
 assert.equal(upcoming.date,'2026-10-25');
 const following=nextISTDaily(21,new Date('2026-10-25T16:00:00Z'));
 assert.equal(following.when.toISOString(),'2026-10-26T15:30:00.000Z');
});
