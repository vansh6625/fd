# Vercel deployment checklist

**No live deployment is claimed.** Deployment requires a connected Vercel account, internet-capable dependency installation, provider keys and testing.

## 1. Create a private repository

Upload the files to GitHub or your own Git service. Ensure `.env` and `.env.local` are not committed.

## 2. Set up Supabase

Create a dedicated production Supabase project. In SQL editor, run `sql/001_initial.sql`. Ensure all RLS policies are active, Email Authentication is configured, the `founderos-reports` bucket is private, and backup policies are enabled. Copy Project URL and anonymous/publishable key. Copy the *service role key* to server-only deployment settings; never expose it to the browser.

## 3. Configure external providers

- OpenAI: API key for speech transcription and structured task extraction.
- Upstash QStash: token and current/next signing keys. Check `notBefore` limits on your QStash plan.
- Web Push: generate VAPID keys, set `NEXT_PUBLIC_VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` and a correct contact `VAPID_SUBJECT`.
- Resend (optional): verify your sending domain and set API key + from email.

## 4. Import repository into Vercel

Go to Vercel > Add New > Project and import repository. Framework should detect Next.js. Set all `.env.example` variables under Project Settings > Environment Variables. Use separate Preview and Production credentials/database instances.

Set `NEXT_PUBLIC_SITE_URL=https://<your-real-vercel-hostname>` (without trailing slash). This URL is embedded in the QStash callback and must exactly match the public origin used for verification. Update auth redirect URL allowlist in Supabase.

## 5. Deploy preview and smoke-test

Deploy a preview after environment variables and SQL migrations are applied. Test login and logout, create text task, voice note transcription with a Hindi sample, multi-task AI extraction, task completion, review status reconciliation, report download, and an actual notification scheduled a few minutes ahead. Check Vercel function logs and browser console. Do not promote to Production if any mandatory flow fails.

## 6. Weekly reporting

`vercel.json` declares a weekly Monday job `0 2 * * 1` (UTC, corresponding to Monday 7:30 AM India time). Set `CRON_SECRET` so Vercel supplies its bearer token to `/api/cron/weekly`. Test with a controlled request and inspect stored PDF. Check whether the Vercel plan's cron limits meet your requirements.

## 7. Production authorization

Promote preview deployment to Production only after explicit approval and verification. Add the final production domain to Supabase auth redirect settings and to `NEXT_PUBLIC_SITE_URL`. Ensure any provider callback signatures continue to validate.

## 8. Hardening before launch

Resolve **all gaps in README**, especially Hindi PDF glyph rendering, daily-review timed reminders, server-side idempotency, and actual third-party delivery tests. Add a monitoring/error reporting provider and backups. The repository is deployment scaffolding, not a completed security certification.
