# Architecture

- Web: Next.js App Router, React Client components with responsive CSS.
- Auth: Supabase SSR cookie sessions, getUser checks on server, middleware refresh.
- Persistence: Supabase Postgres; user-scoped CRUD policies via auth.uid(); private storage bucket.
- AI: Client microphone MediaRecorder -> authenticated `/api/ai/transcribe` -> OpenAI transcription -> `/api/ai/extract` -> JSON schema validation -> user task confirmation -> `/api/tasks`.
- Review: Enter/record status note -> `/api/ai/reconcile` suggests task ID/status pair -> manual approval -> `/api/review` writes changes and daily review note.
- Reminder: Task inserted/modified -> QStash `notBefore` job -> signature-validated `/api/reminders/dispatch` -> read current task/version -> Web Push subscriptions or Resend email -> notification log. Browser service worker receives push.
- Reports: Monday scheduled Vercel cron -> admin-scoped loop -> task records -> React PDF -> private Supabase bucket -> metadata record -> authorized signed-URL download route.
- Metrics: Independent deterministic JavaScript week functions used by server code and unit tests.

## Threat boundaries

User data never flows via client-supplied `user_id` on mutation. RLS always scopes by Supabase auth identity; admin key only used on server for internal callbacks/storage. Reminder callback is signed by QStash and validated. Audio files are size/type restricted; no anonymous AI endpoint.

## Known architectural work before production

Transactional review, historical as-of reporting, per-user daily review scheduling, pagination/background batching, request throttling at the edge, full end-to-end browser automation, centralized monitoring, Hindi-font PDF rendering, retry-safe notification claims and provider integration smoke tests.
