import {createServerClient} from '@supabase/ssr';import {NextResponse,type NextRequest} from 'next/server';
export async function middleware(req:NextRequest){
 let response=NextResponse.next({request:req});
 if(!process.env.NEXT_PUBLIC_SUPABASE_URL||!process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY)return response;
 const client=createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY,{cookies:{getAll(){return req.cookies.getAll()},setAll(items){items.forEach(({name,value})=>req.cookies.set(name,value));response=NextResponse.next({request:req});items.forEach(({name,value,options})=>response.cookies.set(name,value,options));}}});
 await client.auth.getUser();return response;
}
export const config={matcher:['/((?!_next/static|_next/image|favicon.ico|icon.svg|sw.js).*)']};
