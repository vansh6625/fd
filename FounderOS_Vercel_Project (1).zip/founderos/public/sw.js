self.addEventListener('push', event=>{
  let data={title:'FounderOS reminder',body:'You have an upcoming task',url:'/'};
  try {data={...data,...event.data.json()}}catch{}
  event.waitUntil(self.registration.showNotification(data.title,{body:data.body,icon:'/icon.svg',data:{url:data.url},tag:'founderos-task'}));
});
self.addEventListener('notificationclick',event=>{event.notification.close();event.waitUntil(self.clients.openWindow(new URL(event.notification.data?.url||'/',self.location.origin).href))});
