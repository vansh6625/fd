# Security Review — Preliminary

Status: **NOT independently penetration-tested; no production verification.**

## Existing safeguards

- Authentication checked with Supabase `auth.getUser()` on server.
- Row-level access policies on user-owned tables.
- Server-only service role key for automated report/storage jobs.
- Origin checks for state-changing app APIs (supplementary; not a full CSRF strategy).
- JSON validation through Zod; limited transcription file size/mime.
- QStash signatures checked before processing reminder callbacks.
- No credentials hardcoded in repository.
- Task input treated as untrusted in AI prompts.
- Private bucket signed-link report downloads with user-scoped metadata query.

## Unresolved security concerns

- Add robust distributed rate limiting for transcription, registration and API routes (current AI counter is not a strong distributed limiter).
- Confirm Supabase storage admin credential isolation and production RLS policies.
- Audit service-role error logs and provider callback replay/idempotency before public launch.
- Add an anti-abuse gate for email signup, password recovery and report generation.
- Run full production dependency scans and dynamic tests once npm installation is available.
- Avoid enabling public signup until operating posture is ready.
- Validate all browser/mobile push notification permission and deletion flows.
