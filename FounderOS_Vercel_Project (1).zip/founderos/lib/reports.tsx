import React from 'react';
import {Document,Page,Text,View,StyleSheet,renderToBuffer} from '@react-pdf/renderer';
import type {Task} from './schema';
import {summarize} from './week.mjs';
const styles=StyleSheet.create({page:{padding:36,fontSize:9,color:'#172232',fontFamily:'Helvetica'},brand:{fontSize:11,fontWeight:700,color:'#4666da'},title:{fontSize:22,fontWeight:700,marginTop:12},sub:{fontSize:10,color:'#5e6d83',marginTop:6,marginBottom:20},row:{flexDirection:'row',gap:10,marginBottom:12},metric:{padding:12,backgroundColor:'#f1f5fb',flexGrow:1},number:{fontSize:18,fontWeight:700},caption:{fontSize:8,color:'#607087',marginTop:4},section:{fontSize:12,fontWeight:700,marginTop:16,marginBottom:8},entry:{paddingVertical:6,borderBottom:'1 solid #e6ebf2'},footer:{position:'absolute',bottom:20,left:36,right:36,fontSize:8,color:'#94a3b8'}});
export type ReportStats={planned:number,completed:number,pending:number,cancelled:number,overdue:number,completionRate:number};
export function stats(tasks:Task[],start:Date,end:Date):ReportStats{return summarize(tasks,start,end) as ReportStats;}
// PDFs use Helvetica by default; Devanagari glyph support requires a properly licensed embedded Unicode font.
// This is surfaced as a known deployment limitation rather than silently pretending Hindi PDFs have full glyph coverage.
export async function makeReport(tasks:Task[],name:string,start:Date,end:Date){
 const s=stats(tasks,start,end);
 const relevant=tasks.filter(t=>Date.parse(t.created_at)>=+start&&Date.parse(t.created_at)<+end||(t.due_at!=null&&Date.parse(t.due_at)>=+start&&Date.parse(t.due_at)<+end)||(t.completed_at!=null&&Date.parse(t.completed_at)>=+start&&Date.parse(t.completed_at)<+end));
 const safe=(x:string)=>x.replace(/[^\x20-\x7E]/g,'?');
 const doc=<Document title="FounderOS Weekly Report"><Page size="A4" style={styles.page}>
  <Text style={styles.brand}>FOUNDEROS / PRODUCTIVITY</Text><Text style={styles.title}>Weekly work report</Text>
  <Text style={styles.sub}>{safe(name||'Founder')} · {start.toISOString().slice(0,10)} to {new Date(end.getTime()-1).toISOString().slice(0,10)}</Text>
  <View style={styles.row}>{[['Planned',s.planned],['Done',s.completed],['Pending',s.pending],['Completion',`${s.completionRate}%`]].map(([label,num])=><View key={label} style={styles.metric}><Text style={styles.number}>{num}</Text><Text style={styles.caption}>{label}</Text></View>)}</View>
  <Text style={styles.section}>Completed work</Text>{relevant.filter(t=>t.status==='completed').length===0?<Text>No completed items recorded.</Text>:relevant.filter(t=>t.status==='completed').map(t=><View key={t.id} style={styles.entry} wrap={false}><Text>{safe(t.title)}</Text><Text style={styles.caption}>Completed: {t.completed_at?new Date(t.completed_at).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'}):'Unknown'}</Text></View>)}
  <Text style={styles.section}>Pending and postponed</Text>{relevant.filter(t=>['pending','in_progress','postponed'].includes(t.status)).length===0?<Text>No pending items.</Text>:relevant.filter(t=>['pending','in_progress','postponed'].includes(t.status)).map(t=><View key={t.id} style={styles.entry} wrap={false}><Text>{safe(t.title)}</Text><Text style={styles.caption}>Status: {t.status} · Due: {t.due_at?new Date(t.due_at).toLocaleString('en-IN',{timeZone:'Asia/Kolkata'}):'Not scheduled'}</Text></View>)}
  <Text style={styles.section}>Observations</Text><Text>{s.completed} of {s.planned} qualifying tasks are currently marked completed. {s.overdue} remain overdue. Figures reflect task records at report generation time.</Text>
  <Text style={styles.footer} fixed>FounderOS · Generated {new Date().toISOString()} · Confidential</Text>
 </Page></Document>;
 return {buffer:await renderToBuffer(doc),metrics:s};
}
