import { Client } from '@upstash/qstash';
import type { Task } from './schema';
export async function scheduleReminder(task:Task,userId:string,reminderMinutes=30){
 if(!task.due_at || ['completed','cancelled'].includes(task.status)) return null;
 if(!process.env.QSTASH_TOKEN || !process.env.NEXT_PUBLIC_SITE_URL) return null;
 const deliverAt=Math.floor(new Date(task.due_at).getTime()/1000)-reminderMinutes*60;
 if(deliverAt<=Date.now()/1000) return null;
 const client=new Client({token:process.env.QSTASH_TOKEN});
 const res=await client.publishJSON({url:`${process.env.NEXT_PUBLIC_SITE_URL}/api/reminders/dispatch`,body:{taskId:task.id,userId,version:task.updated_at},notBefore:deliverAt,retries:3});
 return res.messageId;
}
