import { NextResponse } from 'next/server';
import { z } from 'zod';
import { AuthError } from './supabase';
export const ok=(data:unknown,status=200)=>NextResponse.json(data,{status,headers:{'Cache-Control':'no-store'}});
export function failure(e:unknown){
 if(e instanceof AuthError) return ok({error:'Authentication required'},401);
 if(e instanceof z.ZodError) return ok({error:'Validation failed',issues:e.flatten()},400);
 console.error('API error:', e instanceof Error?e.message:'Unexpected failure');
 return ok({error:'Request failed. Try again later.'},500);
}
export async function bodyJSON(request:Request,limit=20000){
 const declared=Number(request.headers.get('content-length')||0);
 if(declared>limit) throw new Error('Payload too large');
 const text=await request.text();
 if(text.length>limit) throw new Error('Payload too large');
 return JSON.parse(text);
}
export function originOK(req:Request){const origin=req.headers.get('origin');if(!origin)return true;try {return new URL(origin).host===new URL(req.url).host;}catch{return false}}
