import webpush from 'web-push';
import {supabaseAdmin} from './supabase';
export async function notifyUser(userId:string,title:string,message:string,url:string){
 const admin=supabaseAdmin();const {data:prefs}=await admin.from('profiles').select('push_reminders,email_reminders').eq('id',userId).single();
 let delivered=0;const failures:string[]=[];
 if(prefs?.push_reminders&&process.env.VAPID_PRIVATE_KEY&&process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY){
  webpush.setVapidDetails(process.env.VAPID_SUBJECT||'mailto:admin@example.com',process.env.NEXT_PUBLIC_VAPID_PUBLIC_KEY,process.env.VAPID_PRIVATE_KEY);
  const {data:subs}=await admin.from('push_subscriptions').select('*').eq('user_id',userId);
  for(const sub of subs||[]){try{await webpush.sendNotification({endpoint:sub.endpoint,keys:sub.keys},JSON.stringify({title,body:message,url}));delivered++}catch(e){failures.push('push');const code=(e as {statusCode?:number}).statusCode;if(code===404||code===410)await admin.from('push_subscriptions').delete().eq('id',sub.id)}}
 }
 if(prefs?.email_reminders&&process.env.RESEND_API_KEY){
  const {data}=await admin.auth.admin.getUserById(userId);
  if(data.user?.email){try{const result=await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.REMINDER_FROM_EMAIL||'FounderOS <noreply@example.com>',to:data.user.email,subject:title,text:message})});if(result.ok)delivered++;else failures.push(`email:${result.status}`)}catch{failures.push('email')}}
 }
 return {delivered,failures};
}
