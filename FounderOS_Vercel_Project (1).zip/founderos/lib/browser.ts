import {createBrowserClient} from '@supabase/ssr';
export function supabaseBrowser(){return createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)}
export async function api<T>(url:string,method='GET',body?:unknown):Promise<T>{
 const r=await fetch(url,{method,headers:body?{'Content-Type':'application/json'}:undefined,body:body?JSON.stringify(body):undefined});
 const data=await r.json().catch(()=>({error:`HTTP ${r.status}`}));if(!r.ok)throw new Error(data.error||`HTTP ${r.status}`);return data as T;
}
