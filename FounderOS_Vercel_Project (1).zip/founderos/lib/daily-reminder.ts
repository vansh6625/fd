import {Client} from '@upstash/qstash';
import type {SupabaseClient} from '@supabase/supabase-js';
import {nextISTDaily} from './week.mjs';
export async function ensureDailyReview(supabase:SupabaseClient,userId:string,hour:number){
 if(!process.env.QSTASH_TOKEN||!process.env.NEXT_PUBLIC_SITE_URL)return {scheduled:false,reason:'Scheduler not configured'};
 const {when,date}=nextISTDaily(hour);
 const {data:existing}=await supabase.from('review_reminder_jobs').select('id,status').eq('user_id',userId).eq('local_date',date).eq('hour',hour).maybeSingle();
 if(existing?.status==='scheduled'||existing?.status==='sent')return {scheduled:true,duplicate:true};
 let jobId=existing?.id;
 if(!jobId){const {data,error}=await supabase.from('review_reminder_jobs').insert({user_id:userId,local_date:date,hour,scheduled_at:when.toISOString()}).select('id').single();if(error){if(error.code==='23505')return {scheduled:true,duplicate:true};throw error}jobId=data.id}
 try{const q=new Client({token:process.env.QSTASH_TOKEN});const sent=await q.publishJSON({url:`${process.env.NEXT_PUBLIC_SITE_URL}/api/reminders/review-dispatch`,body:{jobId,userId,date,hour},notBefore:Math.floor(when.getTime()/1000),retries:3});
 await supabase.from('review_reminder_jobs').update({message_id:sent.messageId,status:'scheduled'}).eq('id',jobId).eq('user_id',userId);
 return {scheduled:true,date};
 }catch(e){await supabase.from('review_reminder_jobs').update({status:'failed'}).eq('id',jobId).eq('user_id',userId);throw e}
}
