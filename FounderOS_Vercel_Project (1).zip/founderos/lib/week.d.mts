export function lastClosedWeek(now?:Date):{start:Date;end:Date;weekStart:string};
export function summarize(tasks:Array<{created_at:string;due_at:string|null;completed_at:string|null;status:string}>,start:Date,end:Date,at?:Date):{planned:number;completed:number;pending:number;cancelled:number;overdue:number;completionRate:number};
export function nextISTDaily(hour:number,now?:Date):{when:Date;date:string};
