import {z} from 'zod';
export const taskStatus=z.enum(['pending','in_progress','completed','postponed','cancelled']);
export const taskSchema=z.object({
 title:z.string().min(1).max(240),description:z.string().max(3000).default(''),
 due_at:z.string().datetime({offset:true}).nullable().default(null),
 person:z.string().max(160).nullable().default(null),location:z.string().max(250).nullable().default(null),
 priority:z.enum(['low','medium','high']).default('medium'),category:z.string().max(80).default('General'),
 status:taskStatus.default('pending'),
});
export const taskUpdateSchema=taskSchema.partial().extend({id:z.string().uuid(),status:taskStatus.optional()});
export const extractedSchema=z.object({tasks:z.array(z.object({title:z.string().min(1).max(240),description:z.string().max(3000).default(''),due_at:z.string().nullable().default(null),person:z.string().nullable().default(null),location:z.string().nullable().default(null),priority:z.enum(['low','medium','high']).default('medium'),category:z.string().default('General'),uncertain:z.boolean().default(false),uncertainty_reason:z.string().nullable().default(null)})).max(25)});
export type TaskInput=z.infer<typeof taskSchema>;
export type Task=TaskInput & {id:string,user_id:string,created_at:string,updated_at:string,completed_at:string|null};
