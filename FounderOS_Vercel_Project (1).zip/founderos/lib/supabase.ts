import { createServerClient } from '@supabase/ssr';
import { createClient as createAdminClient } from '@supabase/supabase-js';
import { cookies } from 'next/headers';
export async function supabaseServer(){
 const jar=await cookies();
 return createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,{
  cookies:{getAll(){return jar.getAll()},setAll(items){try{items.forEach(({name,value,options})=>jar.set(name,value,options))}catch{/* immutable render context */}}}
 });
}
export function supabaseAdmin(){
 const secret=process.env.SUPABASE_SERVICE_ROLE_KEY;
 if(!secret) throw new Error('Server service key missing');
 return createAdminClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,secret,{auth:{autoRefreshToken:false,persistSession:false}});
}
export async function requireUser(){
 const supabase=await supabaseServer();
 const {data:{user},error}=await supabase.auth.getUser();
 if(error||!user) throw new AuthError();
 return {supabase,user};
}
export class AuthError extends Error { constructor(){super('Please sign in');this.name='AuthError'} }
